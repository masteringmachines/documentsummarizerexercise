#!/usr/bin/env python3
"""
summarize.py — Document Summarizer CLI

Chapter 1 project: Build a document summarizer.

Usage:
    uv run summarize.py report.txt
    uv run summarize.py contract.pdf
    uv run summarize.py report.txt --detail brief
    uv run summarize.py report.txt --detail detailed
    uv run summarize.py report.txt --json
    uv run summarize.py report.txt --output summary.md
    uv run summarize.py a.txt b.txt c.txt          # combined cross-document summary

Requires:
    uv add openai pydantic pypdf
    export OPENAI_API_KEY=...
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from pydantic import BaseModel, Field

try:
    from openai import OpenAI, APIError, APIConnectionError, RateLimitError
except ImportError:
    print("Missing dependency 'openai'. Install it with: uv add openai", file=sys.stderr)
    sys.exit(1)

try:
    from pypdf import PdfReader
except ImportError:
    print("Missing dependency 'pypdf'. Install it with: uv add pypdf", file=sys.stderr)
    sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────

DEFAULT_MODEL = "gpt-4o-mini"
LONG_DOC_MODEL = "gpt-4o"
LONG_DOC_WORD_THRESHOLD = 10_000
TEMPERATURE = 0.3
MAX_RETRIES = 3
RETRY_BASE_DELAY = 1.5  # seconds, exponential backoff

SUPPORTED_EXTENSIONS = {".txt", ".pdf"}

# Rough per-token pricing in USD (input, output) — update as needed.
PRICING = {
    "gpt-4o-mini": {"input": 0.150 / 1_000_000, "output": 0.600 / 1_000_000},
    "gpt-4o": {"input": 2.50 / 1_000_000, "output": 10.00 / 1_000_000},
}

DETAIL_GUIDANCE = {
    "brief": "1-2 sentence summary, 3 key points",
    "standard": "2-4 sentence summary, 3-5 key points",
    "detailed": "4-6 sentence summary, 5-6 key points with sub-points",
}


# ─────────────────────────────────────────────────────────────────────────
# Structured output model
# ─────────────────────────────────────────────────────────────────────────

class DocumentSummary(BaseModel):
    title: str = Field(description="Inferred title of the document, even if not explicitly stated")
    document_type: str = Field(description='e.g. "legal contract", "technical report", "email thread"')
    estimated_word_count: int = Field(description="Estimated word count of the source document")
    summary: str = Field(description="A prose summary; length depends on requested detail level")
    key_points: list[str] = Field(description="3-6 bullet points capturing the most important content")
    action_items: list[str] = Field(default_factory=list, description="Any action items; may be empty")


# ─────────────────────────────────────────────────────────────────────────
# File reading
# ─────────────────────────────────────────────────────────────────────────

def read_document(path: str) -> str:
    """Read a .txt or .pdf file and return its plain text content."""
    file_path = Path(path)

    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    ext = file_path.suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise ValueError(
            f"Unsupported file type '{ext}'. Supported types: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )

    if ext == ".txt":
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()

    if ext == ".pdf":
        reader = PdfReader(str(file_path))
        pages = [page.extract_text() or "" for page in reader.pages]
        text = "\n\n".join(pages).strip()
        if not text:
            raise ValueError(
                f"No extractable text found in {path}. It may be a scanned/image-only PDF."
            )
        return text

    # Should be unreachable given the earlier check.
    raise ValueError(f"Unsupported file type '{ext}'.")


def word_count(text: str) -> int:
    return len(text.split())


# ─────────────────────────────────────────────────────────────────────────
# Summarization
# ─────────────────────────────────────────────────────────────────────────

def build_system_prompt(detail: str) -> str:
    return f"""You are a precise document summarization assistant used by professionals
(legal, operations, sales) who need accurate, structured summaries of real documents.

Always extract the required fields accurately and ground everything in the document's
actual content — do not invent facts, numbers, or action items that are not implied by
the text.

Requested detail level: {detail}
Guidance for this detail level: {DETAIL_GUIDANCE[detail]}
"""


def build_user_message(document_text: str, detail: str) -> str:
    return f"""<document>
{document_text}
</document>

Summarize the document above. Extract all required fields accurately.
The detail level for this summary is: {detail}
- brief: 1-2 sentence summary, 3 key points
- standard: 2-4 sentence summary, 3-5 key points
- detailed: 4-6 sentence summary, 5-6 key points with sub-points
"""


def choose_model(document_text: str) -> tuple[str, bool]:
    """Return (model_name, used_long_doc_model)."""
    wc = word_count(document_text)
    if wc > LONG_DOC_WORD_THRESHOLD:
        return LONG_DOC_MODEL, True
    return DEFAULT_MODEL, False


def call_with_retry(client: OpenAI, model: str, system_prompt: str, user_message: str):
    """Call the API with retry logic and exponential backoff. Returns the parsed response object."""
    last_error: Exception | None = None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = client.beta.chat.completions.parse(
                model=model,
                temperature=TEMPERATURE,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message},
                ],
                response_format=DocumentSummary,
            )
            return response
        except RateLimitError as e:
            last_error = e
            wait = RETRY_BASE_DELAY * (2 ** (attempt - 1))
            print(f"  Rate limited (attempt {attempt}/{MAX_RETRIES}). Retrying in {wait:.1f}s...", file=sys.stderr)
            time.sleep(wait)
        except APIConnectionError as e:
            last_error = e
            wait = RETRY_BASE_DELAY * (2 ** (attempt - 1))
            print(f"  Connection error (attempt {attempt}/{MAX_RETRIES}). Retrying in {wait:.1f}s...", file=sys.stderr)
            time.sleep(wait)
        except APIError as e:
            # 5xx-style server errors are worth retrying; other API errors are not.
            status = getattr(e, "status_code", None)
            if status is not None and status >= 500:
                last_error = e
                wait = RETRY_BASE_DELAY * (2 ** (attempt - 1))
                print(f"  Server error (attempt {attempt}/{MAX_RETRIES}). Retrying in {wait:.1f}s...", file=sys.stderr)
                time.sleep(wait)
            else:
                raise

    raise last_error if last_error else RuntimeError("API call failed for an unknown reason.")


def summarize(text: str, detail: str, client: OpenAI) -> tuple[DocumentSummary, dict]:
    """
    Summarize `text` at the given detail level.
    Returns (DocumentSummary, usage_info) where usage_info has model/tokens/cost.
    """
    model, used_long_doc_model = choose_model(text)
    if used_long_doc_model:
        print("⚠ Document is long — using gpt-4o for better quality")

    system_prompt = build_system_prompt(detail)
    user_message = build_user_message(text, detail)

    response = call_with_retry(client, model, system_prompt, user_message)

    parsed = response.choices[0].message.parsed
    if parsed is None:
        raise ValueError("Model did not return a parseable structured summary.")

    usage = response.usage
    input_tokens = usage.prompt_tokens if usage else 0
    output_tokens = usage.completion_tokens if usage else 0
    total_tokens = usage.total_tokens if usage else (input_tokens + output_tokens)

    pricing = PRICING.get(model, PRICING[DEFAULT_MODEL])
    cost = input_tokens * pricing["input"] + output_tokens * pricing["output"]

    usage_info = {
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": total_tokens,
        "cost": cost,
    }

    return parsed, usage_info


# ─────────────────────────────────────────────────────────────────────────
# Output formatting
# ─────────────────────────────────────────────────────────────────────────

def format_summary(summary: DocumentSummary, usage_info: dict) -> str:
    lines = []
    lines.append("═" * 39)
    lines.append("  DOCUMENT SUMMARY")
    lines.append("═" * 39)
    lines.append(f"Title:       {summary.title}")
    lines.append(f"Type:        {summary.document_type}")
    lines.append(f"Word count:  ~{summary.estimated_word_count:,}")
    lines.append("─" * 39)
    lines.append("SUMMARY")
    lines.append(summary.summary)
    lines.append("")
    lines.append("KEY POINTS")
    for point in summary.key_points:
        lines.append(f"• {point}")

    if summary.action_items:
        lines.append("")
        lines.append("ACTION ITEMS")
        for item in summary.action_items:
            lines.append(f"• {item}")

    lines.append("─" * 39)
    lines.append(
        f"Cost: ${usage_info['cost']:.6f} | Tokens: {usage_info['total_tokens']:,} "
        f"({usage_info['model']})"
    )
    lines.append("═" * 39)
    return "\n".join(lines)


def format_markdown(summary: DocumentSummary, usage_info: dict, source_files: list[str]) -> str:
    lines = []
    lines.append(f"# {summary.title}")
    lines.append("")
    lines.append(f"**Source file(s):** {', '.join(source_files)}  ")
    lines.append(f"**Document type:** {summary.document_type}  ")
    lines.append(f"**Estimated word count:** ~{summary.estimated_word_count:,}")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    lines.append(summary.summary)
    lines.append("")
    lines.append("## Key Points")
    lines.append("")
    for point in summary.key_points:
        lines.append(f"- {point}")
    if summary.action_items:
        lines.append("")
        lines.append("## Action Items")
        lines.append("")
        for item in summary.action_items:
            lines.append(f"- {item}")
    lines.append("")
    lines.append("---")
    lines.append(
        f"*Cost: ${usage_info['cost']:.6f} | Tokens: {usage_info['total_tokens']:,} "
        f"| Model: {usage_info['model']}*"
    )
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────

def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Summarize a .txt or .pdf document (or multiple documents) using an LLM.",
    )
    parser.add_argument(
        "files",
        nargs="+",
        help="Path(s) to .txt or .pdf file(s) to summarize. "
        "Multiple files produce a combined cross-document summary.",
    )
    parser.add_argument(
        "--detail",
        choices=["brief", "standard", "detailed"],
        default="standard",
        help="Level of detail for the summary (default: standard)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print the raw structured summary as JSON instead of formatted text.",
    )
    parser.add_argument(
        "--output",
        metavar="FILE.md",
        help="Write a formatted Markdown summary to this file in addition to printing it.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv if argv is not None else sys.argv[1:])

    # Read and validate all files up front, before any API calls.
    documents: list[tuple[str, str]] = []  # (path, text)
    for path in args.files:
        try:
            text = read_document(path)
        except FileNotFoundError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1
        documents.append((path, text))

    # Combine multiple documents into one text block for a cross-document summary.
    if len(documents) == 1:
        combined_text = documents[0][1]
    else:
        parts = []
        for path, text in documents:
            parts.append(f"--- Source: {Path(path).name} ---\n{text}")
        combined_text = "\n\n".join(parts)

    try:
        client = OpenAI()
    except Exception as e:
        print(f"Error: could not initialize OpenAI client ({e}).", file=sys.stderr)
        print("Make sure OPENAI_API_KEY is set in your environment.", file=sys.stderr)
        return 1

    try:
        summary, usage_info = summarize(combined_text, args.detail, client)
    except (APIError, APIConnectionError, RateLimitError) as e:
        print(f"API error: could not generate summary. ({e})", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    if args.json:
        print(summary.model_dump_json(indent=2))
    else:
        print(format_summary(summary, usage_info))

    if args.output:
        md = format_markdown(summary, usage_info, [Path(p).name for p, _ in documents])
        try:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(md)
            print(f"\nMarkdown summary written to {args.output}", file=sys.stderr)
        except OSError as e:
            print(f"Warning: could not write output file ({e})", file=sys.stderr)

    return 0


if __name__ == "__main__":
    sys.exit(main())
